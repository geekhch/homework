% GaussianFilterHomework('img08.jpg',2,21);
% ColorFilterHomework('img08.jpg',2,21)
