% GaussianFilterHomework('donald.jpg',2,21);
ColorFilterHomework('donald.jpg',8,11)
