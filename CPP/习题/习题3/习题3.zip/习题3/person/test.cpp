#include "Person.h"
#include <iostream>
using namespace std;

int main()
{
    TeacherCadre tc;
    tc.Show();
    return 0;
}